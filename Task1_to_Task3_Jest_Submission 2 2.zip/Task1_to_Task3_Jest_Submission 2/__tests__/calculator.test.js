const { divide, multiply } = require("../calculator");

describe("Calculator Tests", () => {
  test("divide two positive numbers", () => {
    expect(divide(10, 2)).toBe(5);
  });

  test("divide negative number", () => {
    expect(divide(-10, 2)).toBe(-5);
  });

  test("divide by zero throws error", () => {
    expect(() => divide(10, 0)).toThrow("Cannot divide by zero");
  });

  test("multiply two positive numbers", () => {
    expect(multiply(3, 4)).toBe(12);
  });

  test("multiply by zero", () => {
    expect(multiply(5, 0)).toBe(0);
  });
});
