const UserController = require("../userController");

describe("UserController Tests", () => {
  let controller;

  beforeEach(() => {
    controller = new UserController();
    controller.add({ id: 1, email: "test@example.com" });
    controller.add({ id: 2, email: "user@example.com" });
  });

  test("add() adds a user", () => {
    const user = { id: 3, email: "new@example.com" };
    controller.add(user);
    expect(controller.users.length).toBe(3);
  });

  test("remove() removes a user", () => {
    controller.remove(1);
    expect(controller.findById(1)).toBeUndefined();
  });

  test("findByEmail returns correct user", () => {
    expect(controller.findByEmail("test@example.com").id).toBe(1);
  });

  test("findByEmail returns undefined if not found", () => {
    expect(controller.findByEmail("missing@example.com")).toBeUndefined();
  });

  test("findById returns correct user", () => {
    expect(controller.findById(2).email).toBe("user@example.com");
  });

  test("findById returns undefined if not found", () => {
    expect(controller.findById(99)).toBeUndefined();
  });
});
